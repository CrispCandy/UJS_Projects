import it.unisa.dia.gas.jpbc.Element;

import java.util.Arrays;

//访问树节点：门、门限值、子节点（内部节点）、属性值、秘密值、叶子节点
// 函数：内部节点构造方法、叶子节点构造方法、判断节点方法
public class Node {

    public int[] gate;
    //gate门，用(t,n)表示门限值，n表示结点个数，t表示门限值。
    //若节点是叶子节点返回null值
    public int[] children;
    //children子节点（内部节点）
    public int att;
    //att属性
    public Element secretShare;
    //secretShare加密解密过程中对应的秘密值

    public boolean valid;
    //秘密恢复，判断知否可以恢复的值
    public Node(int[] gate, int[] children){
        this.gate = gate;
        this.children = children;
    }
    //内部节点的构造方法：接受门限值和子节点索引列表作为参数
    public Node(int att){
        this.att = att;
    }
    //叶子节点的构造方法：接受属性值作为参数
    public boolean isLeaf() {
        return this.children==null ? true : false;
    }
    //判断节点是否为叶子节点。是：true，否：false
    @Override
    public String toString() {
        if (this.isLeaf()){
            return Integer.toString(this.att);
        }
        else {
            return Arrays.toString(this.gate);
        }
    }
}
//toString返回结点的字符串表示。
//叶子节点：返回属性值的字符串表示；内部节点：返回门限值的字符串表示