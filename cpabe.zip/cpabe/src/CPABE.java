import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.stream.Collectors;

import static java.lang.Integer.valueOf;

public class CPABE {

    public static void setup(String pairingParametersFileName, String pkFileName, String mskFileName) {

        Pairing bp = PairingFactory.getPairing(pairingParametersFileName);
        //从指定文件中获取配对参数

        Element g = bp.getG1().newRandomElement().getImmutable();
        //在G1群中生成一个随机元素g，并将其设为不可变元素
        Element alpha = bp.getZr().newRandomElement().getImmutable();
        //在Zr群中生成一个随机元素alpha，并将其设为不可变元素
        Element beta = bp.getZr().newRandomElement().getImmutable();
        //在Zr群中生成一个随机元素beta，并将其设为不可变元素

        Element g_alpha = g.powZn(alpha).getImmutable();
        //计算g^alpha，并将其设为不可变元素
        Element g_beta = g.powZn(beta).getImmutable();
        //计算g^beta，并将其设为不可变元素
        Element egg_alpha = bp.pairing(g, g).powZn(alpha).getImmutable();
        //计算e(g,g)^alpha，并将其设为不可变元素

        Properties mskProp = new Properties();
        //创建一个Properties对象，用于储存主密钥msk
        mskProp.setProperty("g_alpha", Base64.getEncoder().withoutPadding().encodeToString(g_alpha.toBytes()));
        //使用Base64编码将g_alpha的值存储在mskProp中
        Properties pkProp = new Properties();
        //创建一个Properties对象，用于储存公钥pk
        pkProp.setProperty("g", Base64.getEncoder().withoutPadding().encodeToString(g.toBytes()));
        //使用Base64编码将g的值储存在pkProp中
        pkProp.setProperty("g_beta", Base64.getEncoder().withoutPadding().encodeToString(g_beta.toBytes()));
        //使用Base64编码将g_beta的值存储在pkProp中
        pkProp.setProperty("egg_alpha", Base64.getEncoder().withoutPadding().encodeToString(egg_alpha.toBytes()));
        //使用Base64编码将egg_alpha的值存储在pkProp中

        storePropToFile(mskProp, mskFileName);
        //将mskProp存储到mskFileName中
        storePropToFile(pkProp, pkFileName);
        //将pkProp存储到pkFileName中
    }


    public static void encrypt(String pairingParametersFileName, Element message, Node[] accessTree,
                               String pkFileName, String ctFileName) throws NoSuchAlgorithmException {
        //接受一些输入参数：包括配对参数文件名、需要加密的消息m、访问树、公钥文件名、密钥文件名
        //方法可能会抛出NoSuchNoSuchAlgorithmException异常
        Pairing bp = PairingFactory.getPairing(pairingParametersFileName);
        //创建一个Pairing对象bp，通过使用给定的参数文件名来获取配对
        Properties pkProp = loadPropFromFile(pkFileName);
        String gString = pkProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(Base64.getDecoder().decode(gString)).getImmutable();
        String g_betaString = pkProp.getProperty("g_beta");
        Element g_beta = bp.getG1().newElementFromBytes(Base64.getDecoder().decode(g_betaString)).getImmutable();
        String egg_alphaString = pkProp.getProperty("egg_alpha");
        Element egg_alpha = bp.getGT().newElementFromBytes(Base64.getDecoder().decode(egg_alphaString)).getImmutable();
        //从公钥属性文件中加载属性，并获取其中的g、g_beta和egg_alpha值
        //使用Base64解码这些值，并将它们转换为相应的Element对象。并设置为不可变对象。
        Properties ctPorp = new Properties();
        //创建一个新的Properties对象ctProp，用于储存生成的密文属性
        Element s = bp.getZr().newRandomElement().getImmutable();
        Element C = message.duplicate().mul(egg_alpha.powZn(s)).getImmutable();
        Element C0 = g.powZn(s).getImmutable();
        //生成一个随机元素s,该元素属于整数环bp.getZr()，并将其设置为不可变对象
        //计算生成C0、C，并设置为不可变对象
        ctPorp.setProperty("C", Base64.getEncoder().withoutPadding().encodeToString(C.toBytes()));
        ctPorp.setProperty("C0", Base64.getEncoder().withoutPadding().encodeToString(C0.toBytes()));
        //将生成的密文值C0和C以Base64编码的形式存储到ctProp属性中
        accessTree[0].secretShare = s;
        nodeShare(accessTree, accessTree[0], bp);
        //将秘密分片secretShare设置为树的根节点的随机元素s
        //然后，调用nodeShare方法来实现秘密分片的共享，以便每个叶子节点获取相应的秘密分片
        for (Node node : accessTree) {
            if (node.isLeaf()) {
                Element r = bp.getZr().newRandomElement().getImmutable();
                byte[] idHash = sha1(Integer.toString(node.att));
                Element Hi = bp.getG1().newElementFromHash(idHash, 0, idHash.length).getImmutable();
                Element C1 = g_beta.powZn(node.secretShare).mul(Hi.powZn(r.negate()));
                Element C2 = g.powZn(r);

                ctPorp.setProperty("C1-" + node.att, Base64.getEncoder().withoutPadding().encodeToString(C1.toBytes()));
                ctPorp.setProperty("C2-" + node.att, Base64.getEncoder().withoutPadding().encodeToString(C2.toBytes()));
            }
        }
        //对于访问树中的每个节点，如果节点是叶子节点，则执行以下操作：
        //生成一个随机元素r，该元素属于整数环bp.getZr()，并将其设置为不可变对象
        //然后，计算并生成密文的C1和C2值。C1的计算通过将g_beta的节点秘密分片的s次方乘以Hi的r的负值指数形式来完成，C2的计算通过将g的r次方来完成
        //然后，将这些值以Base64编码的形式存储到ctProp属性中，使用节点的attributes作为键名
        storePropToFile(ctPorp, ctFileName);
    }

    public static void keygen(String pairingParametersFileName, int[] userAttList, String pkFileName,
                              String mskFileName, String skFileName) throws NoSuchAlgorithmException{
        //Keygen:用于生成密钥对
        //输入参数：配对参数文件名、用户属性列表、公钥文件名、主密钥文件名和密钥文件名、
        Pairing bp = PairingFactory.getPairing(pairingParametersFileName);
        Properties pkProp = loadPropFromFile(pkFileName);
        String gString = pkProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(Base64.getDecoder().decode(gString)).getImmutable();
        String g_betaString = pkProp.getProperty("g_beta");
        Element g_beta = bp.getG1().newElementFromBytes(Base64.getDecoder().decode(g_betaString)).getImmutable();
        //从公钥属性文件中加载属性，并获取其中的g和g_beta值
        //然后，使用Base64解码这些值，并将它们转换为Element对象
        //g和g_beta都将被设置为不可变对象
        Properties mskProp = loadPropFromFile(mskFileName);
        String g_alphaString = mskProp.getProperty("g_alpha");
        Element g_alpha = bp.getG1().newElementFromBytes(Base64.getDecoder().decode(g_alphaString)).getImmutable();
        //从主密钥属性文件中加载属性，并获取其中的g_alpha值
        //然后，使用Base64解码该值，并将其转换为Element对象
        //g_alpha将被设置为不可变对象
        Properties skProp = new Properties();
        Element t = bp.getZr().newRandomElement().getImmutable();
        //生成一个随机元素r
        Element D = g_alpha.mul(g_beta.powZn(t)).getImmutable();
        Element D0 = g.powZn(t);

        skProp.setProperty("D",Base64.getEncoder().withoutPadding().encodeToString(D.toBytes()));
        skProp.setProperty("D0",Base64.getEncoder().withoutPadding().encodeToString(D0.toBytes()));
        //将生成的密钥值D和D0以Base64编码的形式存储到skProp属性中
        for (int attributes : userAttList){
            byte[] idHash = sha1(Integer.toString(attributes));
            Element H = bp.getG1().newElementFromHash(idHash, 0, idHash.length).getImmutable();
            Element Dattributes = H.powZn(t).getImmutable();
            skProp.setProperty("D" + attributes, Base64.getEncoder().withoutPadding().encodeToString(Dattributes.toBytes()));
            //对于用户属性列表中的每个属性，执行以下操作：
            //将属性值转换为字节数组，并计算其哈希值
            //然后，使用哈希值创建一个Element对象H，并将其设置为不可变对象
            //接下来，计算Dattributes的值，通过将H的r次方来完成，并将其设置为不可变对象
            //最后，将生成的Dattributes以Base64编码的形式存储到skProp属性中，属性名为属性值前缀为"D"的字符串。
        }
        skProp.setProperty("userAttList", Arrays.toString(userAttList));
        storePropToFile(skProp, skFileName);
    }

    public static Element Decrypt(String pairingParametersFileName, Node[] accessTree, String ctFileName, String skFileName){
        //Decrypt:
        // 接受四个参数：pairingParametersFileName（配对参数文件名），accessTree（访问树节点数组），ctFileName（密文文件名）和skFileName（秘钥文件名）
        // 该方法返回一个Element对象
        Pairing bp = PairingFactory.getPairing(pairingParametersFileName);
        //Pairing类是基于双线性映射的配对运算库
        Properties ctProp = loadPropFromFile(ctFileName);
        //从密文文件中加载属性到ctProp对象中
        Properties skProp = loadPropFromFile(skFileName);
        //从秘钥文件中加载属性到skProp对象中
        String userAttListString = skProp.getProperty("userAttList");
        int[] userAttList = Arrays.stream(userAttListString.substring(1, userAttListString.length()-1).split(",")).map(String::trim).mapToInt(Integer::parseInt).toArray();
        //从`skProp`属性中获取名为"userAttList"的属性值，并将其转换为整数数组
        //首先，将属性值转换为逗号分隔的字符串数组，然后去除字符串中的前导和尾部空格，接着将每个字符串元素转换为整数，并最终将其存储在`userAttList`数组中
        String CString = ctProp.getProperty("C");
        Element C = bp.getGT().newElementFromBytes(Base64.getDecoder().decode(CString)).getImmutable();
        String C0String = ctProp.getProperty("C0");
        Element C0 = bp.getG1().newElementFromBytes(Base64.getDecoder().decode(C0String)).getImmutable();

        String DString = skProp.getProperty("D");
        Element D = bp.getG1().newElementFromBytes(Base64.getDecoder().decode(DString)).getImmutable();
        String D0String = skProp.getProperty("D0");
        Element D0 = bp.getG1().newElementFromBytes(Base64.getDecoder().decode(D0String)).getImmutable();

        for (Node node : accessTree){
            if (node.isLeaf()){
                if (Arrays.stream(userAttList).boxed().collect(Collectors.toList()).contains(node.att)){
                    String C1String = ctProp.getProperty("C1-"+node.att);
                    Element C1 = bp.getG1().newElementFromBytes(Base64.getDecoder().decode(C1String)).getImmutable();
                    String C2String = ctProp.getProperty("C2-"+node.att);
                    Element C2 = bp.getG1().newElementFromBytes(Base64.getDecoder().decode(C2String)).getImmutable();

                    String DattributeString = skProp.getProperty("D"+node.att);
                    Element Dattributes = bp.getG1().newElementFromBytes(Base64.getDecoder().decode(DattributeString)).getImmutable();

                    node.secretShare = bp.pairing(C1,D0).mul(bp.pairing(C2,Dattributes)).getImmutable();
                }
            }
        }
        //从ctProp属性中获取名为"C"和"C0"的属性值，并使用Base64解码为字节数组
        //然后，使用Pairing对象的getGT()和getG1()方法创建Element对象C和C0，并将解码后的字节数组作为参数传递给相应的newElementFromBytes方法
        //最后，通过调用getImmutable()方法将C和C0设置为不可变（immutable）
        boolean treeOK = nodeRecover(accessTree, accessTree[0], userAttList, bp);
        //调用`nodeRecover`方法，传递访问树、根节点、用户属性列表和`Pairing`对象作为参数，并将返回的布尔值赋给`treeOK`变量
        // `nodeRecover`方法用于进行秘密恢复操作。
        if(treeOK){
            Element egg_alphas = bp.pairing(C0,D).div(accessTree[0].secretShare);
            return C.div(egg_alphas);
        }
        else {
            System.out.println("The access tree is not satisfied.");
            return null;
        }
    }

    //d-1次多项式表示为q(x)=coef[0] + coef[1]*x^1 + coef[2]*x^2 + coef[d-1]*x^(d-1)
    //多项式的系数的数据类型为Zr Element，从而是的后续相关计算全部在Zr群上进行
    //通过随机选取coef参数，来构造d-1次多项式q(x)。约束条件为q(0)=s。
    public static Element[] randomP(int d, Element s, Pairing bp) {
        //接受一个整数d、一个Element对象s和一个Pairing对象bp作为参数
        //用于生成一个随机多项式的系数数组
        Element[] coef = new Element[d];
        coef[0] = s;
        //创建一个长度为d的Element数组coef，并将参数s赋值给数组的第一个元素coef[0]，作为多项式常数项
        for (int i = 1; i < d; i++) {
            coef[i] = bp.getZr().newRandomElement().getImmutable();
        }
        //从索引1开始遍历数组coef，为每个索引生成一个随机的Element对象，并将其赋值给coef[i]
        //这些随机元素将作为多项式的其他系数。getImmutable()方法确保生成的元素是不可变的
        return coef;
    }

    public static Element qx(Element index, Element[] coef, Pairing bp) {
        //函数接受一个Element对象index、一个Element数组coef和一个Pairing对象bp作为参数
        //该方法用于计算由系数数组coef确定的多项式在给定点index处的值
        Element res = coef[0].getImmutable();
        //将数组coef的第一个元素coef[0]赋值给结果变量res
        //这是多项式的常数项
        for (int i = 1; i < coef.length; i++) {
            Element exp = bp.getZr().newElement(i).getImmutable();
            res = res.add(coef[i].mul(index.duplicate().powZn(exp)));
            //从索引1开始遍历数组coef，对于每个索引，计算对应的指数exp
            // 然后，将指数exp应用于给定点index的副本，通过调用powZn()方法进行指数运算，并将其与系数coef[i]相乘
            // 最后，将乘积结果累加到结果变量res中。
        }
        return res;
    }

    public static Element lagrange(int i, int[] S, int x, Pairing bp) {
        //拉格朗日插值定理：接受一个整数i、一个整数数组S、一个整数x和一个Pairing对象bp作为参数
        //计算拉格朗日因子
        Element res = bp.getZr().newOneElement().getImmutable();
        Element iElement = bp.getZr().newElement(i).getImmutable();
        Element xElement = bp.getZr().newElement(x).getImmutable();
        //创建一个结果变量res，并将其初始化为1
        //将参数i、x分别作为Element对象iElement和xElement的值
        for (int j : S) {
            if (i != j) {
                Element numerator = xElement.sub(bp.getZr().newElement(j));
                Element denominator = iElement.sub(bp.getZr().newElement(j));
                res = res.mul(numerator.div(denominator));
            }
        }
        //对于数组S中的每个元素j，如果i不等于j，则执行：
        //首先，计算分子为xElement减去j的Element对象numerator，计算分母为iElement减去j的Element对象denominator
        //然后，将分子除以分母，并将结果乘以结果变量res
        return res;
    }

    // 共享秘密
    // nodes是整颗树的所有节点，n是要分享秘密的节点
    public static void nodeShare(Node[] nodes, Node n, Pairing bp) {
        //函数接受一个Node数组nodes、一个Node对象n和一个Pairing对象bp作为参数
        //该方法用于在节点数组中进行秘密共享。
        if (!n.isLeaf()) {
            Element[] coef = randomP(n.gate[0], n.secretShare, bp);
            //生成一个随机多项式的系数数组coef，多项式的常数项为当前节点的秘密值n.secretShare
            //多项式的次数由结点的gate对应的threshold决定
            for (int j = 0; j < n.children.length; j++) {
                Node childNode = nodes[n.children[j]];
                childNode.secretShare = qx(bp.getZr().newElement(n.children[j]), coef, bp);
                nodeShare(nodes, childNode, bp);
                //对于数组S中的每个元素j，如果i不等于j，则执行以下操作：
                // 首先，计算分子为xElement减去j的Element对象numerator，计算分母为iElement减去j的Element对象denominator
                // 然后，将分子除以分母，并将结果乘以结果变量res
            }
        }
    }


    // 恢复秘密
    public static boolean nodeRecover(Node[] nodes, Node n,  int[] atts, Pairing bp) {
        //该函数接受一个Node数组nodes，一个Node对象n，一个整数数组attributes和一个Pairing对象bp作为参数
        //该方法用于节点的秘密恢复，并返回一个布尔值表示节点是否满足条件
        if (!n.isLeaf()) {
            //如果节点n不是叶子节点，则在方法中创建一个validChildrenList列表，用于储存满足条件的子节点的索引
            //同时，定义一个validChildren数组，用于储存满足条件的子节点索引
            List<Integer> validChildrenList = new ArrayList<Integer>();
            // 对于内部节点，维护一个子节点索引列表，用于秘密恢复。
            int[] validChildren;
            // 遍历每一个子节点
            for (int j=0; j<n.children.length; j++){
                Node childNode = nodes[n.children[j]];
                // 递归调用，恢复子节点的秘密值
                if (nodeRecover(nodes, childNode, atts, bp)){
                    System.out.println("The node with index " + n.children[j] + " is sarisfied!");
                    validChildrenList.add(valueOf(n.children[j]));
                    // 如果满足条件的子节点个数已经达到门限值，则跳出循环，不再计算剩余的节点
                    if (validChildrenList.size() == n.gate[0]) {
                        n.valid = true;
                        break;
                    }
                    //如果满足条件的子节点个数已经达到门限值，则跳出循环，不再计算剩余的节点
                }
                else {
                    System.out.println("The node with index " + n.children[j] + " is not sarisfied!");
                }
            }
            //如果可恢复的子节点个数等于门限值，则利用子节点的秘密分片恢复当前节点的秘密。
            //对于节点n的每个子节点，通过递归调用nodeRecover方法，恢复子节点的秘密值
            //如果子节点满足条件，则将其索引添加到validChildrenList列表中，并打印相应的满足和不满足信息
            //如果满足条件的子节点个数达到门限值，将节点n的valid属性设置为true，并跳出循环，不再计算剩余的节点
            if (validChildrenList.size() == n.gate[0]){
                validChildren = validChildrenList.stream().mapToInt(i->i).toArray();
                // 利用拉格朗日差值恢复秘密
                // 注意，此处是在指数因子上做拉格朗日差值
                Element secret = bp.getGT().newOneElement().getImmutable();
                for (int i : validChildren) {
                    Element delta = lagrange(i, validChildren, 0, bp);  //计算拉个朗日插值因子
                    secret = secret.mul(nodes[i].secretShare.duplicate().powZn(delta)); //基于拉格朗日因子进行指数运算，然后连乘
                }
                n.secretShare = secret;
            }
        }
        else {
            // 判断叶子节点的属性值是否属于属性列表
            // 判断一个元素是否属于数组，注意String类型和int类型的判断方式不同
            if (Arrays.stream(atts).boxed().collect(Collectors.toList()).contains(n.att)){
                n.valid = true;
            }
        }
        return n.valid;
        //该函数是递归地恢复节点的秘密值，并判断节点是否满足条件
        //对于内部节点，通过递归调用恢复子节点的秘密值，如果满足条件的子节点个数达到门限值，则使用拉格朗日插值方法恢复当前节点的秘密值
        //对于叶子节点，则判断属性值是否属于属性列表
        //最终返回节点是否满足条件的结果

    }

    public static void storePropToFile(Properties prop, String fileName) {
        try (FileOutputStream out = new FileOutputStream(fileName)) {
            //尝试打开指定文件名的FileOutputStream
            prop.store(out, null);
            //将属性存储到输出流中
        } catch (IOException e) {
            //捕捉IOException异常
            e.printStackTrace();
            //打印异常的堆栈跟踪信息
            System.out.println(fileName + " save failed");
            //打印保存失败的提示信息
            System.exit(-1);
            //强制退出程序，返回状态码-1
        }
    }

    public static Properties loadPropFromFile(String fileName) {
        //接受一个fileName参数，并返回一个Properties对象
        //该方法用于加载属性
        Properties prop = new Properties();
        //创建一个新的Properties对象prop，用于储存加载的属性
        try (FileInputStream in = new FileInputStream(fileName)) {
            prop.load(in);
        }
        //使用FileInputStream打开指定的文件fileName，并将其作为输入流传递给prop.load()方法。
        //prop.load()方法将加载输入流中的属性
        catch (IOException e) {
            e.printStackTrace();
            System.out.println(fileName + "加载失败！");
            System.exit(-1);
        }
        return prop;
    }

    public static byte[] sha1 (String content) throws NoSuchAlgorithmException {
        //哈希算法
        //接受一个字符串content作为参数，并且声明可能抛出NoSuchAlgorithmException异常
        //该方法用于计算给定内容的SHA-1哈希值，并返回一个字节数组。
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        //创建一个MessageDigest实例，使用指定的算法名称"SHA-1"
        //MessageDigest类提供了消息摘要算法的功能，用于计算数据的哈希值
        instance.update(content.getBytes());
        //将字符串content转换为字节数组，并将其传递给MessageDigest实例的update方法
        //这将更新MessageDigest对象的状态，以便计算哈希值
        return instance.digest();
        //调用MessageDigest实例的digest方法，计算并返回最终的哈希值作为字节数组
        //digest方法将返回一个固定长度的字节数组，表示SHA-1哈希值
    }

    public static void basicTest() throws Exception {
        int[] userAttList = {1, 2, 3,4};

//        Node[] accessTree = new Node[7];
//        accessTree[0] = new Node(new int[]{2,3}, new int[]{1,2,3});
//        accessTree[1] = new Node(1);
//        accessTree[2] = new Node(new int[]{2,3}, new int[]{4,5,6});
//        accessTree[3] = new Node(5);
//        accessTree[4] = new Node(2);
//        accessTree[5] = new Node(3);
//        accessTree[6] = new Node(4);

        Node[] accessTree = new Node[5];
        accessTree[0] = new Node(new int[]{4,4}, new int[]{1,2,3,4});
        accessTree[1] = new Node(1);
        accessTree[2] = new Node(2);
        accessTree[3] = new Node(3);
        accessTree[4] = new Node(4);

        String dir = "data/";
        String pairingParametersFileName = "a.properties";
        String pkFileName = dir + "pk.properties";
        String mskFileName = dir + "msk.properties";
        String skFileName = dir + "sk.properties";
        String ctFileName = dir + "ct.properties";

        setup(pairingParametersFileName, pkFileName, mskFileName);
        keygen(pairingParametersFileName, userAttList, pkFileName, mskFileName, skFileName);

        Element message = PairingFactory.getPairing(pairingParametersFileName).getGT().newRandomElement().getImmutable();
        System.out.println("明文消息:" + message);
        encrypt(pairingParametersFileName, message, accessTree, pkFileName, ctFileName);

       Element res = Decrypt(pairingParametersFileName, accessTree, ctFileName, skFileName);
        System.out.println("解密结果:" + res);

        if (message.isEqual(res)) {
            System.out.println("成功解密！");
        }
    }
    public static void main(String[] args) throws Exception {
        basicTest();
    }

}
